<?php $__env->startSection('content'); ?>
    <h3>Mahasiswa</h3>
    <a class="btn btn-info mb-4" href="<?php echo e(url('/add-mahasiswa')); ?>">Add Mahasiswa</a>
    <table class="table table-striped">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Name</th>
            <th scope="col">NIM</th>
            <th scope="col">Faculty</th>
            <th scope="col">Major</th>
            <th scope="col">Gender</th>
            <th scope="col">Action</th>
          </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $mahasiswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mahasiswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($mahasiswa->id); ?></th>
                    <td><?php echo e($mahasiswa->name); ?></td>
                    <td><?php echo e($mahasiswa->nim); ?></td>
                    <td><?php echo e($mahasiswa->faculty); ?></td>
                    <td><?php echo e($mahasiswa->major); ?></td>
                    <td><?php echo e($mahasiswa->gender); ?></td>
                    <td style="display: flex">
                        <div>
                            <a href="<?php echo e(url('/edit-mahasiswa/'.$mahasiswa->id)); ?>" class="btn btn-primary mr-3">Edit</a>
                        </div>
                        <form action="<?php echo e(url('/delete-mahasiswa/'.$mahasiswa->id)); ?>" method="POST">
                            <?php echo e(method_field('DELETE')); ?>

                            <?php echo e(csrf_field()); ?>

                            <button class="btn btn-danger" type="submit">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\BINUS\Semester 5\Web Programming\AssignmentWebProgLEC\assignmentwebproglec\resources\views/welcome.blade.php ENDPATH**/ ?>