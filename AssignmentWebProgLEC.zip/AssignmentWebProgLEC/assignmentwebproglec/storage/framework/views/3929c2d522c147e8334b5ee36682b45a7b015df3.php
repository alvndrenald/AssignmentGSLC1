<a href="<?php echo e(url('/')); ?>">Go Back</a>
<h1>This is Home Page !</h1>


<?php /**PATH E:\BINUS\Semester 5\Web Programming\AssignmentWebProgLEC\assignmentwebproglec\resources\views/home.blade.php ENDPATH**/ ?>