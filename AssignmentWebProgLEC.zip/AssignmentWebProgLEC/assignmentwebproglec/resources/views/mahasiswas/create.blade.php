@extends('layout.master')

@section('content')
    <h3>You Can Add Data Mahasiswa Here!</h3>
    <a class="btn btn-info mb-4" href="{{url('/')}}">Go Back</a>
    <form action="{{url('/add-mahasiswa')}}" method="POST">
        {{ csrf_field() }}
        <div class="form-group">
            <label for="exampleFormControlInput1" class="form-label">Name</label>
            <input type="text" name="name" class="form-control" placeholder="Ex. Alvindra Renaldo">
        </div>

        <div class="form-group">
            <label for="exampleFormControlInput1" class="form-label">NIM</label>
            <input type="text" name="nim" class="form-control" placeholder="Ex. 2440007705">
        </div>

        <div class="form-group">
            <label for="exampleFormControlInput1" class="form-label">Faculty</label>
            <input type="text" name="faculty" class="form-control" placeholder="Ex. School of Computer Science">
        </div>

        <div class="form-group">
            <label for="exampleFormControlInput1" class="form-label">Major</label>
            <input type="text" name="major" class="form-control" placeholder="Ex. Computer Science">
        </div>

        <div class="form-group">
            <label for="exampleFormControlInput1" class="form-label">Gender</label>
            <input type="text" name="gender" class="form-control" placeholder="Ex. Male">
        </div>
    </form>
    <button class="btn btn-primary mt-3">Submit</button>
@endsection

