@extends('layout.master')

@section('content')
    <h3>Mahasiswa</h3>
    <a class="btn btn-info mb-4" href="{{url('/add-mahasiswa')}}">Add Mahasiswa</a>
    <table class="table table-striped">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Name</th>
            <th scope="col">NIM</th>
            <th scope="col">Faculty</th>
            <th scope="col">Major</th>
            <th scope="col">Gender</th>
            <th scope="col">Action</th>
          </tr>
        </thead>
        <tbody>
            @foreach ($mahasiswas as $mahasiswa)
                <tr>
                    <th scope="row">{{$mahasiswa->id}}</th>
                    <td>{{$mahasiswa->name}}</td>
                    <td>{{$mahasiswa->nim}}</td>
                    <td>{{$mahasiswa->faculty}}</td>
                    <td>{{$mahasiswa->major}}</td>
                    <td>{{$mahasiswa->gender}}</td>
                    <td style="display: flex">
                        <div>
                            <a href="{{url('/edit-mahasiswa/'.$mahasiswa->id)}}" class="btn btn-primary mr-3">Edit</a>
                        </div>
                        <form action="{{url('/delete-mahasiswa/'.$mahasiswa->id)}}" method="POST">
                            {{method_field('DELETE')}}
                            {{ csrf_field() }}
                            <button class="btn btn-danger" type="submit">Delete</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
@endsection
