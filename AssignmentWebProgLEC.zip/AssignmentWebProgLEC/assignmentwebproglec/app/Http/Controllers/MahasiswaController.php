<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Mahasiswa;
use Illuminate\Support\Facades\DB;

class MahasiswaController extends Controller
{
    public function index(){
        $mahasiswas = Mahasiswa::all();
        return view('welcome',compact('mahasiswas'));
    }

    public function create(){
        return view('mahasiswas.create');
    }

    public function store(Request $request){
        DB::table('mahasiswas')->insert([
            'name' => $request->name,
            'nim' => $request->nim,
            'faculty' => $request->faculty,
            'major' => $request->major,
            'gender' => $request->gender
        ]);
        return redirect()->route('/');
    }

    public function edit($mahasiswa){
        $mahasiswa = Mahasiswa::find($mahasiswa);
        return view('mahasiswas.edit', compact('mahasiswa'));
    }

    public function update(Request $request, $mahasiswa){
        $input = $request->all();
        $mahasiswa = Mahasiswa::find($mahasiswa);
        $mahasiswa->name = $input['name'];
        $mahasiswa->nim = $input['nim'];
        $mahasiswa->faculty = $input['faculty'];
        $mahasiswa->major = $input['major'];
        $mahasiswa->gender = $input['gender'];

        $mahasiswa->save();
    }

    public function delete($mahasiswa){
        Mahasiswa::find($mahasiswa)->delete();
        return redirect()->back();
    }
}
